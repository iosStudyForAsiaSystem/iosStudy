The following icons were made available under the Creative Commons Attribution
License 3.0 by FatCow (http://www.fatcow.com/free-icons/):

large/arrow_divide.png
large/arrow_down.png
large/arrow_join.png
large/arrow_up.png
large/table_row_insert.png